using ImGuiNET;
using Recompiled;
using RecompOne.Runtime;
using RecompOne.Runtime.Context;
using RecompOne.Runtime.Dispatch;
using RecompOne.Runtime.Events;
using RecompOne.Runtime.Memory;
using RecompOne.Runtime.Modding;
using Sotn;

namespace IntroSkipMod;

public sealed class IntroSkip : IMod
{
    private const string Version = "0.1.0";
    private const string ModeSetting = "mods.intro-skip.mode";
    private const uint GameStepAddress = 0x80073060u;
    private const uint NewGameFlagAddress = 0x8003C730u;
    private const uint FileSelectIndexAddress = 0x801D6B04u;
    private const uint FileSelectEntriesAddress = 0x801BC8E0u;
    private const uint FinishVideoPlaybackAddress = 0x800E4970u;
    private const ushort PrologueStage = 0x1F;
    private const ushort EntranceFirstVisit = 0x41;
    private const int FileSelectEngineStep = 51;
    private const Button Directions = Button.Up | Button.Down | Button.Left | Button.Right;

    private static readonly string[] ModeNames =
    [
        "Off",
        "Skip Richter prologue",
        "Skip movie + Richter prologue",
        "Auto-start slot 1 + skip both"
    ];

    private static IntroSkip? _instance;

    private StartupMode _mode;
    private AutoStartPhase _autoStartPhase;
    private AutoStartPhase _phaseAfterDelay;
    private Button _autoButton;
    private int _phaseFrames;
    private bool _openingNewGame;
    private string _status = "Waiting for a new game";

    public void OnLoad()
    {
        _instance = this;
        _mode = (StartupMode)System.Math.Clamp(
            Runtime.View.GetInt(ModeSetting, (int)StartupMode.SkipMovieAndPrologue),
            (int)StartupMode.Off,
            (int)StartupMode.AutoStartSlotOne);
        Event.AddListener<VSyncEvent>(OnVSync);
        Event.AddListener<PadReadEvent>(OnPadRead);
        Event.AddListener<PlayerLoadedEvent>(OnPlayerLoaded);
        Event.AddListener<RuntimeReadyEvent>(OnRuntimeReady);
        ResetAutoStart();
    }

    public void OnUnload()
    {
        Event.RemoveListener<VSyncEvent>(OnVSync);
        Event.RemoveListener<PadReadEvent>(OnPadRead);
        Event.RemoveListener<PlayerLoadedEvent>(OnPlayerLoaded);
        Event.RemoveListener<RuntimeReadyEvent>(OnRuntimeReady);
        ClearTransientState();
        _instance = null;
    }

    public void DrawSettings()
    {
        ImGui.TextDisabled($"Intro Skip v{Version}");

        int mode = (int)_mode;
        if (ImGui.Combo("Startup mode", ref mode, ModeNames, ModeNames.Length))
        {
            _mode = (StartupMode)mode;
            Runtime.View.SetInt(ModeSetting, mode);
            Runtime.SaveView();
            ResetAutoStart();
        }

        ImGui.TextWrapped(_mode switch
        {
            StartupMode.Off => "Uses the unmodified opening flow.",
            StartupMode.SkipPrologue => "Keeps the opening movie, then starts Alucard at Castle Entrance.",
            StartupMode.SkipMovieAndPrologue => "Skips the opening movie and playable Richter section.",
            _ => "Advances through the title and File Select, then loads slot 1 only when the selector reports it as occupied. Empty, moved, or unreadable slots stop without confirmation."
        });

        if (_mode == StartupMode.AutoStartSlotOne && ImGui.Button("Run auto-start again"))
            ResetAutoStart();

        ImGui.Separator();
        ImGui.TextWrapped($"Status: {_status}");
    }

    private void ResetAutoStart()
    {
        ClearTransientState();
        _phaseFrames = 0;
        _autoStartPhase = _mode == StartupMode.AutoStartSlotOne
            ? AutoStartPhase.WaitForTitle
            : AutoStartPhase.Disabled;
        _status = _mode == StartupMode.AutoStartSlotOne
            ? "Waiting for the title screen"
            : "Waiting for a new Alucard game";
    }

    private void ClearTransientState()
    {
        _autoButton = 0;
        _openingNewGame = false;
    }

    private void OnRuntimeReady(RuntimeReadyEvent e) => ResetAutoStart();

    private void OnVSync(VSyncEvent e)
    {
        if (_mode != StartupMode.AutoStartSlotOne || !Game.Available)
        {
            _autoButton = 0;
            return;
        }

        uint gameStep = e.Memory.ReadU32(GameStepAddress);
        uint engineStep = e.Memory.ReadU32(Game.EngineStepAddr);
        switch (_autoStartPhase)
        {
            case AutoStartPhase.WaitForTitle:
                if (Game.State == GameState.Title && gameStep == 6 && engineStep == 2)
                {
                    _status = "Starting from the title screen";
                    Hold(Button.Start, 2, AutoStartPhase.WaitForMainMenu);
                }
                break;

            case AutoStartPhase.WaitForMainMenu:
                if (Game.State == GameState.MainMenu && gameStep == 6 && engineStep == 2)
                {
                    _status = "Opening File Select";
                    Hold(Button.Cross, 2, AutoStartPhase.WaitForFileSelect);
                }
                break;

            case AutoStartPhase.WaitForFileSelect:
                if (Game.State == GameState.MainMenu && engineStep == FileSelectEngineStep)
                {
                    if (e.Memory.ReadU32(FileSelectIndexAddress) != 0)
                    {
                        StopAutoStart("Stopped because the selection moved away from slot 1");
                    }
                    else if (!CanLoadSlotOne(e.Memory))
                    {
                        StopAutoStart("Stopped because slot 1 is empty or unavailable");
                    }
                    else
                    {
                        _status = "Loading occupied slot 1";
                        Hold(Button.Cross, 2, AutoStartPhase.Complete);
                    }
                }
                break;

            case AutoStartPhase.Holding:
                if (--_phaseFrames <= 0)
                {
                    _autoButton = 0;
                    _autoStartPhase = AutoStartPhase.Releasing;
                    _phaseFrames = 12;
                }
                break;

            case AutoStartPhase.Releasing:
                if (--_phaseFrames <= 0)
                    _autoStartPhase = _phaseAfterDelay;
                break;

            case AutoStartPhase.Complete:
                _autoButton = 0;
                _status = "Occupied slot 1 selected; waiting for the normal load flow";
                _autoStartPhase = AutoStartPhase.Disabled;
                break;
        }
    }

    private void Hold(Button button, int frames, AutoStartPhase next)
    {
        _autoButton = button;
        _phaseFrames = frames;
        _phaseAfterDelay = next;
        _autoStartPhase = AutoStartPhase.Holding;
    }

    private void StopAutoStart(string status)
    {
        _autoButton = 0;
        _autoStartPhase = AutoStartPhase.Disabled;
        _status = status;
    }

    private void OnPadRead(PadReadEvent e)
    {
        if (e.Port != 0 || _autoButton == 0)
            return;

        bool confirmingSlot = _autoStartPhase == AutoStartPhase.Holding &&
            _phaseAfterDelay == AutoStartPhase.Complete && _autoButton == Button.Cross;
        if (confirmingSlot)
        {
            e.Buttons |= (ushort)Directions;
            if (!CanLoadSlotOne(e.Memory))
            {
                e.Buttons |= (ushort)Button.Cross;
                StopAutoStart("Stopped because occupied slot 1 was no longer selected");
                return;
            }
        }

        e.Buttons = (ushort)(e.Buttons & ~(ushort)_autoButton);
    }

    private static bool CanLoadSlotOne(IMemory memory) =>
        memory.ReadU32(FileSelectIndexAddress) == 0 &&
        (int)memory.ReadU32(FileSelectEntriesAddress) >= 0;

    private void OnPlayerLoaded(PlayerLoadedEvent e)
    {
        _openingNewGame = false;
        if (_mode == StartupMode.AutoStartSlotOne)
        {
            _autoButton = 0;
            _autoStartPhase = AutoStartPhase.Disabled;
            _status = $"Loaded {e.Character}";
        }
    }

    [PostHook("sel", "func_801ACEC0")]
    private static void SelectAlucardOpening(CpuContext context, IMemory memory)
    {
        IntroSkip? mod = _instance;
        if (mod == null || mod._mode < StartupMode.SkipPrologue)
            return;
        if (memory.ReadU32(Game.PlayableCharacterAddr) != (uint)PlayableCharacter.Alucard)
            return;

        ushort stage = memory.ReadU16(Game.StageIdAddr);
        bool newGame = memory.ReadU32(NewGameFlagAddress) == 0;
        if (stage != PrologueStage && (stage != EntranceFirstVisit || !newGame))
            return;

        mod._openingNewGame = true;
        if (stage == PrologueStage)
            memory.WriteU16(Game.StageIdAddr, EntranceFirstVisit);
        mod._status = "New Alucard game will start at Castle Entrance";
    }

    [PreHook("dra", "HandleVideoPlayback")]
    private static bool SkipOpeningMovie(CpuContext context, IMemory memory)
    {
        IntroSkip? mod = _instance;
        if (mod == null || mod._mode < StartupMode.SkipMovieAndPrologue || !mod._openingNewGame)
            return true;

        mod._status = "Skipping the opening movie";
        mod._openingNewGame = false;
        Dispatcher.Call(context, memory, FinishVideoPlaybackAddress);
        return false;
    }

    private enum StartupMode
    {
        Off,
        SkipPrologue,
        SkipMovieAndPrologue,
        AutoStartSlotOne
    }

    private enum AutoStartPhase
    {
        Disabled,
        WaitForTitle,
        WaitForMainMenu,
        WaitForFileSelect,
        Holding,
        Releasing,
        Complete
    }
}

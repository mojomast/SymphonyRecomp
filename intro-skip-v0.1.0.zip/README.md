# Intro Skip

Intro Skip provides three cumulative startup modes for SymphonyRecomp:

1. **Skip Richter prologue** keeps the opening movie but changes a new Alucard game's pending stage from the playable Richter prologue to the first Castle Entrance visit.
2. **Skip movie + Richter prologue** also invokes the video handler's normal cleanup/loading transition before playback starts.
3. **Auto-start slot 1 + skip both** presses Start at the ready title screen, opens File Select, and loads slot 1 when it is occupied.

The default mode is **Skip movie + Richter prologue**. Change it from the mod settings panel.

The auto-start mode never creates or overwrites save data. It checks the selector's slot metadata immediately before confirmation. If slot 1 is empty, unavailable, or no longer selected, automation stops without pressing Cross.

## Safety

- New-game initialization remains in the original game flow.
- The prologue skip changes only stage `0x1F` to first-visit entrance stage `0x41` after the SEL new-game sequence chooses its starting stage.
- The movie skip reuses the original video handler's cleanup transition into the normal loading state.
- Existing save loading still runs through the original user interface.
- Disabling or unloading the mod releases all synthetic input.
- A runtime reset clears transient movie and input state, then rearms auto-start when that mode is selected.

## Install

Copy this directory into SymphonyRecomp's `mods` directory, then enable **Intro Skip** from the Mods panel. Source mods are compiled when enabled, so the first enable may take a moment.
